"""Entrypoint for module"""

from encryptme_stats import main

if __name__ == "__main__":

    main()
